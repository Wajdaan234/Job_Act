-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2024 at 02:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vision`
--
CREATE DATABASE IF NOT EXISTS `vision` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `vision`;

-- --------------------------------------------------------

--
-- Table structure for table `job-listing`
--

CREATE TABLE `job-listing` (
  `id` int(11) NOT NULL,
  `Category` varchar(200) NOT NULL,
  `jobtitle` varchar(200) NOT NULL,
  `Company` varchar(300) NOT NULL,
  `City` varchar(100) NOT NULL,
  `item` varchar(300) NOT NULL,
  `date` varchar(11) NOT NULL,
  `salary` varchar(50) NOT NULL,
  `maxsalary` varchar(255) NOT NULL,
  `jobtype` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `detail` varchar(3000) NOT NULL,
  `education` varchar(255) NOT NULL,
  `experiance` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job-listing`
--

INSERT INTO `job-listing` (`id`, `Category`, `jobtitle`, `Company`, `City`, `item`, `date`, `salary`, `maxsalary`, `jobtype`, `location`, `detail`, `education`, `experiance`, `email`, `contact`) VALUES
(9, 'Accountant', 'Accountant (Part-Time) Gulshan-e-Iqbal', 'AMZONER Consulting', 'Karachi', 'HUK Enterprise* is looking to hire an Accountant the ideal candidate will bhi responsible for managing and overseeing our financial processes\r\nProficient in managing all aspect of accounts Payable including vendor relations, invoice....', '2024-08-31', '15000', '20000', 'Part-Time', 'Karachi', 'HUK Enterprises is looking to hire an “Accountant” the ideal candidate will be responsible for managing and overseeing our financial processes, ensuring accurate and timely financial reporting, and providing valuable insights to drive business decisions.\r\nThis is a part time (1 hour) onsite job.\r\nPrepare accurate and timely financial statements, reports, and summaries. Analyze financial data to provide actionable insights.\r\nMonitor and analyze production costs, including materials, labor, and overhead. Implement cost control measures and provide recommendations for cost reduction.\r\nAssist in the preparation of budgets and forecasts. Track performance against budgets and provide variance analysis.\r\nManage accounts payable and receivable processes. Ensure timely and accurate processing of invoices and payments.\r\nSupport the management of inventory, ensuring accurate valuation and cost accounting.\r\nEnsure compliance with financial regulations and standards. Assist in internal and external audits as needed.', 'Bachelor’s degree in Accounting , Finance or a related field is preferred.', 'At least 1-2 year of experiance in accounting Field ', 'career@amzoner.com', 'Null'),
(10, 'Software Engineer', 'Junior Software Engineer (Internship)', 'Arkhitech', 'Karachi', 'Cultivating engineering best practices within the engineering group, and, in conjunction with senior engineers, company wide.\r\nCollaborating with technical leaders to analyze complex feature requests and suggest implementation strategies.....', '2024-09-07', '80000', '120000', 'Contract', 'Karachi Sindh', 'Overview:  Arkhitech is seeking talented fresh Software Engineers for internship, that enjoy building advanced internet applications, and designing great APIs. To qualify for the interview, you MUST have either 3.5+ GPA, OR highly sophisticated and professionally developed FYP, OR demonstration of sophisticated software engineering expertise and application outside of classroom, OR have datastructures, algorithms, and design patterns on your fingertips.\r\nCultivating engineering best practices within the engineering group, and, in conjunction with senior engineers, company wide.\r\nCollaborating with technical leaders to analyze complex feature requests and suggest implementation strategies.\r\nEstimate the time required to complete the work and provide quotes.\r\nPerforming moderately complex product design, systems analysis and programming activities requiring research.\r\nConducting unit testing (including mocking as needed) and integration testing on software.\r\nAdhering to Arkhitech\'s policies, standards and procedures in the performance of job duties.\r\nOther duties as assigned.', 'Bachelor’s degree in Computer Science, Software Engineering', 'At least 1-2 year of experiance in this Field ', 'Employer14344@gmail.com', 'Null'),
(11, 'AI Artificial Intelligence', 'AI (Artificial Intelligence) Trainer', 'Nicon group Of Collage', 'Rawalpindi', 'As an AI Trainer, your role is to educate and guide individuals or teams in understanding and appling artificial intelligence concepts andtechnologies', '2024-09-08', '50000', '60000', 'Part-Time', 'Rawalpindi ', 'As an AI Trainer, your role is to educate and guide individuals or teams in understanding and applying artificial intelligence concepts and technologies. This involves delivering training programs, workshops, or courses that cover various aspects of AI, from fundamentals to advanced applications.\r\nData collection, cleaning, and preprocessing.\r\nFeature engineering and selection.\r\nHandling missing data and outliers.\r\nAbility to commute/relocate:\r\nRawalpindi: Reliably commute or planning to relocate before starting work (Preferred).', 'Preferred: 1 year', 'Experiance in AI Artificial Intelligence (Preferred)', 'Employer14344@gmail.com', 'Null');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(255) NOT NULL,
  `roll` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `username`, `email`, `password`, `roll`) VALUES
(11, 'Adeel123', 'adeel12@gmail.com', 'adeel1234', 'user'),
(12, 'Muzmmil', 'MMuzammil2311f@aptechorangi.com', 'muji123', 'user'),
(13, 'Wania', 'wani123@gmail.com', 'wania123', 'user'),
(14, 'Salman', 'salman@gmail.com', '12345', 'user'),
(15, 'Wania', 'wania123@gmail.com', 'wania456', 'user'),
(16, 'Wania', 'wania123@gmail.com', 'wania456', 'user'),
(17, 'Wania', 'wania123@gmail.com', 'wania456', 'user'),
(18, 'Wania', 'wania123@gmail.com', 'wania456', 'user'),
(20, 'admin', 'admin143@gmail.com', 'admin', 'user'),
(21, 'admin', 'admin143@gmail.com', '$2y$10$tls4S87M', 'user'),
(22, 'admin', 'admin143@gmail.com', '$2y$10$Zl8oW/RksQGe4tEIvxnkrePIC4TG3Jiv.MjvaQBqYa5eDsCCjTeWS', 'user'),
(23, 'secure', 'secure12@gmail.com', '$2y$10$7GRTxrMEoJfISgRzWVQU2e7evv53YJN.2NkeScZi.vaRWh1XxaKHa', 'user'),
(24, 'jarvis', 'jarvis@gmail.com', '$2y$10$ymehMHfvvQXnZp8SYGsraeyRiKG6xnUJYIQa9X/nJQ.hzp7WCxIne', 'user'),
(25, 'jarvis', 'jarvis@gmail.com', '$2y$10$iiJuKC8lUQtykShF2FLI2ebm2LIZAXkKvBNE8gyYrOqu8pyIZ9dWu', 'user'),
(26, 'jarvis', 'jarvis@gmail.com', '$2y$10$G5ivfmz4LECbhsE6oXSoy.IFTgo8v19t/QGeEYeXfapFLFKEwJse6', 'user'),
(27, 'jarvis', 'jarvis@gmail.com', '$2y$10$7HHONMLttQZoZDb4u4SGtOzotuB2dx90XYA1t1Sazz9TvPXEziGWO', 'user'),
(28, 'jarvis', 'jarvis@gmail.com', '$2y$10$sF9qGek3Qg4g2.fb1puWeOAmR6mKEKQvKIwqAhFyh/zH7KWhAUgNW', 'user'),
(29, 'jarvis', 'jarvis@gmail.com', '$2y$10$gSyk1AC8brITXRMwOl9C1ugwiuNxnIheKLMvA6btcU4zRWJCHgQu2', 'user'),
(30, 'jarvis', 'jarvis@gmail.com', '$2y$10$ov3ZtFoWBwdnrL0Z9lHwK.L1H9hA3RaYXDx2qqELLPJ8kVQdtKLjG', 'user'),
(31, 'jarvis', 'jarvis@gmail.com', '$2y$10$3ILcRC303aoL73kLei6l2.hzo40i.P.fc4dLBB3e0Xo2q72QzPKaW', 'user'),
(32, 'jarvis', 'jarvis@gmail.com', '$2y$10$LJNzhy6Fn9hJEViFEwxp.uIMIQ7lSD0uO4zmJkNcREPj98NhchBqy', 'user'),
(33, 'jarvis', 'jarvis@gmail.com', '$2y$10$bIuqLwwqn35YfET9pnx3D.utGd0k9yM5lrazGbvGN9CN9XfZ6ucnm', 'user'),
(34, 'jarvis', 'jarvis@gmail.com', '$2y$10$vowuIEdjCsIiXU36XtoG4.tyJWJ.gYNVJYHbww3C3.AoKQBB/b2CS', 'user'),
(35, 'jarvis', 'jarvis@gmail.com', '$2y$10$G8ydR1sg1jzoNHhK2K3lwOGqcWvkTFLrRXbimJayBhWk9/eoubr2W', 'user'),
(36, 'jarvis', 'jarvis@gmail.com', '$2y$10$zbQXVwpt6nZPjQ3p23RSj.nYONiDo4BUJg9lxDkVBV17yj8CM.1dS', 'user'),
(37, 'jarvis', 'jarvis@gmail.com', '$2y$10$RIV1KBADCFYIPUXIzWM6Wu5/u8X1l5UY08PUS4/NqFkDdZP.JP5VK', 'user'),
(38, 'jarvis', 'jarvis@gmail.com', '$2y$10$iA1ObFMVtEGJaYkhH6eBA.lw8kAdxh4.HQfjatphWjJVThqnh8ASS', 'user'),
(39, 'jarvis', 'jarvis@gmail.com', '$2y$10$aDA171vRcJhgMyd1Kl2n2uKERYd1qTNcV8XS3s9jNuMWaJqAB6hxq', 'user'),
(40, 'jarvis', 'jarvis@gmail.com', '$2y$10$65sJw0oVbiKXINaVCXIln.Pz0ViepfsSeKX2ziD.586TGbYUFzYDi', 'user'),
(41, 'jarvis', 'jarvis@gmail.com', '$2y$10$.rA3.DHf5KRDgs27LlIHiefR2GKJJFYn00jWIhiI4ROYT5t3wZJUa', 'user'),
(42, 'jarvis', 'jarvis@gmail.com', '$2y$10$sdsHB7s9Ee9GWB7fA42mgeFi9RzhLoXEr8fR5JBRoLZFNdzuoQOQq', 'user'),
(43, 'jarvis', 'jarvis@gmail.com', '$2y$10$3DWNH0xWqvB49sO9ecZMH.qRUSRaiYTMffswHN0q55b47R04KNowC', 'user'),
(44, 'jarvis', 'jarvis@gmail.com', '$2y$10$KjN/JK56h5mRNXeCUnNZCuquHa5zdscwgjQW9IWp6ec5jlxzPDxaK', 'user'),
(45, 'jarvis', 'jarvis@gmail.com', '$2y$10$lU6./0YIuaBZUNkJVKqgHO3V44rqwTBv/h.6r2Q1ywqa/E8sVNMjW', 'user'),
(46, 'jarvis', 'jarvis@gmail.com', '$2y$10$X/h0Un.HI2NRqMAoQA1ps.vQa8RGyNteZhDDjDaI0kAS6nOcQB8sC', 'user'),
(47, 'jarvis', 'jarvis@gmail.com', '$2y$10$qIb1Z4tWr9ZBaz7VWVH1huNSHAZfBds.R02dSQIZrnWpk5oCyGuH6', 'user'),
(48, 'jarvis', 'jarvis@gmail.com', '$2y$10$9f2lrzFIl5xy/itoZKLYI.1EvYmPXeDUHsKka2cyMKVJrmbJiNFcy', 'user'),
(49, 'jarvis', 'jarvis@gmail.com', '$2y$10$zrDShEPvO8zvjJAltGmgGOyVrIKQ6zpom8.ceXruKekZIDbdejyxS', 'user'),
(50, 'jarvis', 'jarvis@gmail.com', '$2y$10$H9ap9qE/VNSGd2J5dS21qOZbchRV39chbq/FVaW8rDaSxU9KzkJa.', 'user'),
(51, 'jarvis', 'jarvis@gmail.com', '$2y$10$7GG.uYuelkRA70SYXbsW5eTk05zMiVJxLLS99jr9P5FtlNMYPOfbu', 'user'),
(52, 'jarvis', 'jarvis@gmail.com', '$2y$10$bxUB4lQbQn4JUjP8xPq7teefLvnKllxQtvTlSl3mZbKDwPhgaI6Hq', 'user'),
(53, 'jarvis', 'jarvis@gmail.com', '$2y$10$AHrwGJnT35/xVWKvAgghVOVDzzwoVmKWngzO5XDMRvzjyfztJf40q', 'user'),
(54, 'jarvis', 'jarvis@gmail.com', '$2y$10$./WX5gqi0LggiqpN0c2ejetUskq/0zJjrp1YvX71Esrmz6pZinVlm', 'user'),
(55, 'jarvis', 'jarvis@gmail.com', '$2y$10$obXo5asoNFlP7PfbDkJso.ZkMrYZaqJVf.ojpY5IhBx9AZuyv71jG', 'user'),
(56, 'jarvis', 'jarvis@gmail.com', '$2y$10$e.6S0StMfLr1H/c5XN7D/.G7n2mfwD4IDKSQujsxYU0BxUcEj7Bee', 'user'),
(57, 'jarvis', 'jarvis@gmail.com', '$2y$10$p2Jn9yKkuYvI.MIRcgu7PeSwlk8ZSjocCNWf6n7lXyFzSB2TkdHLK', 'user'),
(58, 'jarvis', 'jarvis@gmail.com', '$2y$10$ScxCZE7neWEXRWOp6eI3CeoTs6g6..J5FY6YtbJKaLHflhsVFmQca', 'user'),
(59, 'jarvis', 'jarvis@gmail.com', '$2y$10$F5cJmKzBF9Bwa86Dtlfgh.hCZyR4WbJPWSUx3xpE/lL2GTQGhBmqC', 'user'),
(60, 'jarvis', 'jarvis@gmail.com', '$2y$10$d9CKUg5/flaZyh5VR2dhIuqI3LnHeCNiD5H3VM5364tAdnpFX.sFi', 'user'),
(61, 'jarvis', 'jarvis@gmail.com', '$2y$10$OO8yG5nKvJuAFW.LIaRTBOqy7y9yBv8Yr3EbMqnB4q3w5QEB6xIXO', 'user'),
(62, 'jarvis', 'jarvis@gmail.com', '$2y$10$4.zCTUfoqOtlNNDRnv8XUuhFNpquK15.9FxXnZbhi/c9KgrmyYJxG', 'user'),
(63, 'jarvis', 'jarvis@gmail.com', '$2y$10$c3bpfXJO/xTGHVH8nqzXyuwjoS214Bo/VJNAoB1NY7O2eGRkGcpy6', 'user'),
(64, 'jarvis', 'jarvis@gmail.com', '$2y$10$RQ3b4l0aLhwWrYpG6GVmnuzt1rLOF8WbWHsdidH4MltUYbCS0G8kW', 'user'),
(65, 'jarvis', 'jarvis@gmail.com', '$2y$10$aAXEwjuYpRAkz4fIz8h7ouy.maU4lh5lNOk.pjly9Xt0MrqId.a3y', 'user'),
(66, 'jarvis', 'jarvis@gmail.com', '$2y$10$nqqTtmncFCe27T/lkgLwLuMdAtWIIXG6lMQXUTK2Eg8a/UPg0X.NC', 'user'),
(67, 'jarvis', 'jarvis@gmail.com', '$2y$10$skUac.wjCCkMGRfdm7jjXOv5pB1.S9TxfEiCe3L2jabTSZVjsUdFu', 'user'),
(68, 'jarvis', 'jarvis@gmail.com', '$2y$10$cJF9CsxA4qf0tyXmuMawG.rZdQOenMqFVpuGwi7hqZZ35FoQfmx0K', 'user'),
(69, 'jarvis', 'jarvis@gmail.com', '$2y$10$PzWrL5aOH3cEdaDfim1nE..s1nLqa15QEzfDlDM7ljzENXEmDK3Hi', 'user'),
(70, 'jarvis', 'jarvis@gmail.com', '$2y$10$3e.PTwft2brPZWsMC0uvPeuNntWzTK4ejFNUNJt8CvT9q9TOpIqci', 'user'),
(71, 'jarvis', 'jarvis@gmail.com', '$2y$10$NcOmYFN6s9Wokq2yEjU7yOrwN/acCWY5l4L48dfk.jWvz21KR1Bee', 'user'),
(72, 'jarvis', 'jarvis@gmail.com', '$2y$10$RHMOaCQJoynJX8zQrGqB.unPLTMyL6JT6wryNq2vXmIoyU/Lxsm4K', 'user'),
(73, 'jarvis', 'jarvis@gmail.com', '$2y$10$613EXpm/UUANCOToKo0vvuQ4rAGAHXpIInsfnFz4TQLYANPWJhPgK', 'user'),
(74, 'jarvis', 'jarvis@gmail.com', '$2y$10$i2mB2No1RWto0l6jSRi2We/gd0M2mmCrElwnLfia1kw1KsymUGPnS', 'user'),
(75, 'jarvis', 'jarvis@gmail.com', '$2y$10$1tsCmh91acepWU0Sj97Qs.7/a1E0WL7Ruyjao4LZOwgMwZ2utv6vm', 'user'),
(76, 'jarvis', 'jarvis@gmail.com', '$2y$10$ZYdVpu29OSsXbL84eUG5b.4wzjF8IEPwNsaFDUCw59H3FT33BFmMi', 'user'),
(77, 'jarvis', 'jarvis@gmail.com', '$2y$10$LbvswNnAxZ5J67u1oY31k.qh9yciZOQolv2Vt2.WH59vQP..3U/MC', 'user'),
(78, 'jarvis', 'jarvis@gmail.com', '$2y$10$/hd84Dko0S3873UgE5LLC.QhI7Du.SdFteE7tGHfkZUHi56pbUdQK', 'user'),
(79, 'jarvis', 'jarvis@gmail.com', '$2y$10$S9/jNP6ySLEPLGfrdTYNpujYFJh3sZUod0Hx3OPywPIpPOFKYSrQK', 'user'),
(80, 'jarvis', 'jarvis@gmail.com', '$2y$10$BaO3yebnZ.vcRd12MSsj/OjUkbP24I7/5K1p1KvzbhE7dqgNfMG9W', 'user'),
(81, 'jarvis', 'jarvis@gmail.com', '$2y$10$zYKRo/CiJfK2s66L6yt/3uCvjahZT2JhgRinM4r5v/TjBMTjnqyPi', 'user'),
(82, 'jarvis', 'jarvis@gmail.com', '$2y$10$6D2gTXCq5V/0/QxBfbyIxuN3XF50XtlmNfx0FiNG0fYD6C9o1WfFe', 'user'),
(83, 'jarvis', 'jarvis@gmail.com', '$2y$10$gsmjiTibBf.hkROvbLDBiOYuIT6HAWOC/0e5RCgY8plFceMBbayNm', 'user'),
(84, 'jarvis', 'jarvis@gmail.com', '$2y$10$OwAIb2SZqQd86POi33DSjuNqMHaXXXw57nAcyegN8ArFY9vTlEGgy', 'user'),
(85, 'jarvis', 'jarvis@gmail.com', '$2y$10$QCwUDvQTN.2umWXlK6NBcOhgD1ebQvow5yTdtphrLD2KFWlChqhgG', 'user'),
(86, 'jarvis', 'jarvis@gmail.com', '$2y$10$fydDWX5Gr68IIT35Y1gR8ed5JxhOKVU0EKmsW8XTVH2/vI.XszuwS', 'user'),
(87, 'jarvis', 'jarvis@gmail.com', '$2y$10$Lk9prGHLcoZVScSs7YjdpehPex1WeSdZ5sAeLue6dxx.sbX4M72Ke', 'user'),
(88, 'jarvis', 'jarvis@gmail.com', '$2y$10$TUuikmS/VM1cCQ53vyK/8OQPrC8jDITuM5E2ujygyXq3o/QXTdD26', 'user'),
(89, 'jarvis', 'jarvis@gmail.com', '$2y$10$Vn7Q55EdbnUpEbN5rsrHdOgWlKVbRr1X.O2NJsBuI/1YqJjSnXh2i', 'user'),
(90, 'jarvis', 'jarvis@gmail.com', '$2y$10$UTmscTvBhL7WJ2Km9LTE8uavJvjbzvkakkkpU/LU77HXSczvdTp.2', 'user'),
(91, 'jarvis', 'jarvis@gmail.com', '$2y$10$/DkmDcJbPhcF6nJbftGnVeRAaSYHS9vG/aDHbv.URU6uFCeBb5oYa', 'user'),
(92, 'Aiman', 'basec414@gmail.com', '$2y$10$wgFDzHONEncTjHxAxB/ShuQa8QibLuZvzZBVpns/3TZastci/on4S', 'user'),
(93, 'Admin', 'admin@gmail.com', '$2y$10$AKYhbxfshJGq8pStBMjgL.hmfLKai1qzWCtMfRYtKwoID80bm23A.', 'user'),
(94, 'jalil14344', 'jalil@gmail.com', '$2y$10$e2lSCt4/HOV.HLuCZqiFqON6SyZm9HGm3zuD8xBzG8rejX.tVLKNu', 'user'),
(95, 'Aliyan', 'aliyan@gmail.com', '$2y$10$e9Of1R0Ad/6NSem1QHZ2ZuBo1.KUE2dLUE96lMLK2AgPl5gGNhD9y', 'user'),
(96, 'Amna', 'amna@gmail.com', '$2y$10$lBaleFIKlHONSUOZ7DyhH.1A9s.aloTghUOmZ/B24WEnqmU3w7rLi', 'user'),
(97, 'Test404', 'test404@gmail.com', '$2y$10$fnbpJC9LNDSUw1okmWsrJu49YD8t4vUz73EgzOhoHCIXz4Lkk.kcm', 'user'),
(100, 'Final808', 'final808@gmail.com', '$2y$10$eMSfdhyXMtLmYuKpb3wP1O2qUxSKHdIAsKpN9PCJmI/BSLCQ.fjli', 'user'),
(101, 'Final101', 'final101@gmail.com', 'F123456l', 'user'),
(102, 'Horizon4', 'horizon@gmail.com', '$2y$10$CClc1LbxYLwcFa2a.T1JG.cOJd40CMYRz6o8PU2mVDED4B0n9lPSG', 'employer'),
(103, 'Final102', 'final102@gmail.com', '$2y$10$c/IgVqy.nZY3Fubqkge2IuJG7Hk6Z5Er5ljiOpt8kDiiyyfN73bAG', 'seeker'),
(104, 'Muzammil220', 'muzammil2021@gmail.com', '$2y$10$RPOf8wSRyskq9dcwZdXDheki0DyUfl.KMdKtNLf71Rmb/XSSw4o5u', 'seeker'),
(105, 'Test909', 'test909@gmail.com', '$2y$10$qBa2C4y.Y8XJPDbM0/vXueii0/oaqmvLh22b.XUkGTMra.0AYQJrC', 'employer'),
(106, 'Seeker123', 'seeker@gmail.com', '$2y$10$rOGj54W5wHoa./u66nUmMuZA1/zCDUSjeH/Zs.rWzEYWByzhUHjPm', 'seeker'),
(107, 'Employer123', 'employer@gmail.com', '$2y$10$9uCnEh0CQmuDguUu4ao.KeIsNZg9beca0SkBCT1cAmgUdUASFeyOK', 'employer'),
(108, 'Employer14344', 'Employer14344@gmail.com', '$2y$10$JRU.A7IMnDVRUP6FZ4VYy.SOQJIlFxPMpvaiustCXW3weOw5iKMo6', 'employer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `job-listing`
--
ALTER TABLE `job-listing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `job-listing`
--
ALTER TABLE `job-listing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
